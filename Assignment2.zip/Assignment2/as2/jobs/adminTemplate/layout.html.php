<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <link rel="stylesheet" href="/styles.css" />
    <title>Jo's Jobs - <?php echo htmlspecialchars($title ?? 'Recruitment'); ?></title>
</head>
<body>
    <?php
    // Make sure the session is started so we can read login information.
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }
    ?>

    <header>
        <section>
            <aside>
                <h3>Office Hours:</h3>
                <p>Mon-Fri: 09:00-17:30</p>
                <p>Sat: 09:00-17:00</p>
                <p>Sun: Closed</p>
            </aside>
            <h1>Jo's Jobs</h1>
        </section>
    </header>

    <nav>
        <ul>
            <li><a href="/">Home</a></li>
            <li>
                <a href="/jobs.php">Jobs</a>
                <ul>
                    <?php
                    // Ensure we always have an array when rendering categories.
                    $globalCategories = $globalCategories ?? [];
                    foreach ($globalCategories as $category) {
                        $categoryName = htmlspecialchars($category['name']);
                        $categoryId = (int) $category['id'];
                        echo "<li><a href=\"/jobs.php?cat={$categoryId}\">{$categoryName}</a></li>";
                    }
                    ?>
                </ul>
            </li>
            <li><a href="/careers.php">Careers Advice</a></li>
            <li><a href="/contact.php">Contact Us</a></li>

            <?php if (!empty($_SESSION['loggedin'])) { ?>
                <li><a href="/admin/jobs.php"><strong>Admin Dashboard</strong></a></li>
                <li><a href="/admin/logout.php">Logout (<?php echo htmlspecialchars($_SESSION['username']); ?>)</a></li>
            <?php } else { ?>
                <li><a href="/admin/index.php">Login</a></li>
            <?php } ?>
        </ul>
    </nav>

    <img src="/images/randombanner.php" alt="Jobs Banner" />

    <main class="sidebar">
        <?php
        // The page content is inserted here by the controller.
        echo $content;
        ?>
    </main>

    <footer>
        &copy; Jo's Jobs <?php echo date('Y'); ?>
    </footer>
</body>
</html>