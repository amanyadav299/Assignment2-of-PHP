<section class="left">
    <ul>
        <li><a href="/admin/jobs.php">Manage Jobs</a></li>
        <li><a href="/admin/categories.php">Manage Categories</a></li>
        <li><a href="/admin/enquiries.php">Customer Enquiries Ledger</a></li>
        <li><a href="/admin/users.php">Staff & Client Profiles</a></li>
    </ul>
</section>

<section class="right">
    <h2>Customer Service Enquiries Ledger Matrix</h2>
    <table border="1" cellpadding="8" style="width:100%; background:#fff; border-collapse:collapse;">
        <thead>
            <tr style="background:#eee;">
                <th>Customer Details</th>
                <th>Enquiry Content</th>
                <th>Status</th>
                <th>Handled By</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($enquiries)): ?>
                <tr><td colspan="5">No tracking data entries present inside system.</td></tr>
            <?php else: ?>
                <?php foreach ($enquiries as $enq): ?>
                    <tr>
                        <td>
                            <strong><?= htmlspecialchars((string)($enq['firstname'] ?? '') . ' ' . (string)($enq['surname'] ?? '')) ?></strong><br>
                            <small><?= htmlspecialchars((string)($enq['email'] ?? '')) ?><br><?= htmlspecialchars((string)($enq['telephone'] ?? '')) ?></small>
                        </td>
                        <td><?= nl2br(htmlspecialchars((string)($enq['enquiry_text'] ?? ''))) ?></td>
                        <td>
                            <?= ((string)($enq['status'] ?? '') === 'Complete') ? '<span style="color:green;font-weight:bold;">Resolved</span>' : '<span style="color:red;font-weight:bold;">Pending</span>' ?>
                        </td>
                        <td>
                            <?= (!empty($enq['staff_username'])) ? '✔️ ' . htmlspecialchars((string)$enq['staff_username']) : '<em>Awaiting Ownership</em>' ?>
                        </td>
                        <td>
                            <?php if ((string)($enq['status'] ?? '') === 'Pending'): ?>
                                <form method="POST" action="/admin/enquiries.php" style="margin:0;">
                                    <input type="hidden" name="resolve_id" value="<?= (int)$enq['id'] ?>">
                                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars((string)($csrfToken ?? '')) ?>">
                                    <input type="submit" value="Mark Complete" style="padding:2px 6px; font-size:11px; margin:0; width:auto;">
                                </form>
                            <?php else: ?>
                                Locked/Logged
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</section>
