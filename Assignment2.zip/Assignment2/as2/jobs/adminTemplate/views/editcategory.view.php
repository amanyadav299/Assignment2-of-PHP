<h2>Rename Classification</h2>
<form action="/admin/editcategory.php?id=<?= (int)($cat['id'] ?? 0) ?>" method="POST" style="background:#fff; padding:20px; border:1px solid #ddd;">
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars((string)($csrfToken ?? '')) ?>">
    <label>Category Name:</label><input type="text" name="name" value="<?= htmlspecialchars((string)($cat['name'] ?? '')) ?>" required style="width:100%; max-width:300px;"><br><br>
    <input type="submit" value="Update Class">
</form>
