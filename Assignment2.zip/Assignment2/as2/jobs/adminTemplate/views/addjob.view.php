<h2>Post a New Available Job Opening</h2>
<p style="color:#555;">Use this form to publish a role quickly and keep the listing details current for applicants.</p>
<?php if (!empty($error)): ?>
    <p style="background:#fff4f4; border:1px solid #e0b4b4; color:#8a1f1f; padding:10px; border-radius:4px;"><?= htmlspecialchars((string)$error) ?></p>
<?php endif; ?>
<form action="/admin/addjob.php" method="POST" style="background:#fff; padding:20px; border:1px solid #ddd;">
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken ?? '') ?>">
    <div style="margin-bottom:10px;">
        <label>Job Title:</label>
        <input type="text" name="title" value="<?= htmlspecialchars((string)($formData['title'] ?? '')) ?>" required style="width:100%;">
    </div>
    <div style="margin-bottom:10px;">
        <label>Category:</label>
        <select name="categoryId" required style="width:100%;">
            <option value="">-- Select a category --</option>
            <?php foreach ($globalCategories as $cat): ?>
                <option value="<?= (int)$cat['id'] ?>" <?= ((int)($formData['categoryId'] ?? 0) === (int)$cat['id']) ? 'selected' : '' ?>><?= htmlspecialchars((string)$cat['name']) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div style="margin-bottom:10px;">
        <label>Location:</label>
        <input type="text" name="location" value="<?= htmlspecialchars((string)($formData['location'] ?? '')) ?>" required style="width:100%;">
    </div>
    <div style="margin-bottom:10px;">
        <label>Salary:</label>
        <input type="text" name="salary" value="<?= htmlspecialchars((string)($formData['salary'] ?? '')) ?>" required style="width:100%;" placeholder="e.g. 35000">
    </div>
    <div style="margin-bottom:10px;">
        <label>Closing Date:</label>
        <input type="date" name="closingDate" value="<?= htmlspecialchars((string)($formData['closingDate'] ?? '')) ?>" required style="width:100%;">
    </div>
    <div style="margin-bottom:10px;">
        <label>Description:</label>
        <textarea name="description" required style="width:100%; height:150px;" placeholder="Summarise the role, skills needed, and who should apply."><?= htmlspecialchars((string)($formData['description'] ?? '')) ?></textarea>
    </div>
    <input type="submit" value="Save and Publish Listing" style="width:auto; padding:6px 20px;">
</form>
