<h2>Add New Classification</h2>
<form action="/admin/addcategory.php" method="POST" style="background:#fff; padding:20px; border:1px solid #ddd;">
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars((string)($csrfToken ?? '')) ?>">
    <label>Category Name:</label><input type="text" name="name" required style="width:100%; max-width:300px;"><br><br>
    <input type="submit" value="Save Class">
</form>
