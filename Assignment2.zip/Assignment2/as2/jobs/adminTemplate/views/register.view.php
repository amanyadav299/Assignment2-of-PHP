<h2>Administration Access Registration</h2>
<?php if (!empty($error)): ?>
    <div style="color:red; font-weight:bold; margin-bottom:15px;"><?= htmlspecialchars((string)$error) ?></div>
<?php endif; ?>
<?php if (!empty($success)): ?>
    <div style="color:green; font-weight:bold; margin-bottom:15px;"><?= htmlspecialchars((string)$success) ?></div>
<?php endif; ?>

<?php if (empty($success)): ?>
<form action="/admin/register.php" method="POST" style="background:#fff; padding:20px; border:1px solid #ddd; max-width:400px;">
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars((string)($csrfToken ?? '')) ?>">
    <div style="margin-bottom:10px;">
        <label style="display:block;">Username:</label>
        <input type="text" name="username" required style="width:100%;" placeholder="At least 3 characters">
    </div>
    <div style="margin-bottom:10px;">
        <label style="display:block;">Password:</label>
        <input type="password" name="password" required style="width:100%;" placeholder="At least 6 characters">
    </div>
    <div style="margin-bottom:10px;">
        <label style="display:block;">Confirm Password:</label>
        <input type="password" name="confirm_password" required style="width:100%;">
    </div>
    <input type="submit" value="Register Account" style="width:auto; padding:6px 15px;">
</form>

<div style="margin-top:15px;">
    <p>Already have an account? <a href="/admin/index.php">Login here</a></p>
</div>
<?php endif; ?>
