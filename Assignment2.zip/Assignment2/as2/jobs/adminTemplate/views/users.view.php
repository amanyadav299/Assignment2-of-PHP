<section class="left">
    <ul>
        <li><a href="/admin/jobs.php">Manage Jobs</a></li>
        <li><a href="/admin/categories.php">Manage Categories</a></li>
        <li><a href="/admin/enquiries.php">Customer Enquiries Ledger</a></li>
        <li><a href="/admin/users.php">Staff & Client Profiles</a></li>
    </ul>
</section>

<section class="right">
    <h2>User Accounts Profiles Ledger</h2>
    <?php if (!empty($message)): ?>
        <div style="background:#eee; padding:10px; margin-bottom:15px; font-weight:bold;"><?= htmlspecialchars((string)$message) ?></div>
    <?php endif; ?>

    <form method="POST" action="/admin/users.php" style="background:#f9f9f9; padding:15px; border:1px solid #ddd; margin-bottom:20px;">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars((string)($csrfToken ?? '')) ?>">
        <h3>Register New Account Profile</h3>
        <div style="margin-bottom:8px;">
            <label>Username:</label>
            <input type="text" name="username" required style="width:100%; max-width:300px;">
        </div>
        <div style="margin-bottom:8px;">
            <label>Password:</label>
            <input type="password" name="password" required style="width:100%; max-width:300px;">
        </div>
        <div style="margin-bottom:8px;">
            <label>Workspace Access Role Group:</label>
            <select name="role" required style="width:100%; max-width:300px;">
                <option value="staff">Internal Agency Staff Member</option>
                <option value="client">External Corporate Client Workspace</option>
            </select>
        </div>
        <input type="submit" name="create_user" value="Register Profile Account" style="width:auto; padding:5px 15px;">
    </form>

    <table border="1" cellpadding="8" style="width:100%; background:#fff; border-collapse:collapse;">
        <thead>
            <tr style="background:#eee;">
                <th>Profile ID Reference</th>
                <th>Username Access ID</th>
                <th>Security Level Role</th>
                <th>Workspace Administration Tools</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($allUsers as $u): ?>
                <tr>
                    <td><?= htmlspecialchars((string)$u['id']) ?></td>
                    <td><?= htmlspecialchars((string)$u['username']) ?></td>
                    <td><strong><?= htmlspecialchars(strtoupper((string)$u['role'])) ?></strong></td>
                    <td>
                        <?php if ((int)$u['id'] !== \App\Auth::userId()): ?>
                            <a href="/admin/users.php?delete_id=<?= (int)$u['id'] ?>" onclick="return confirm('Permanently remove this user profile?');" style="color:red;">Revoke Access & Delete</a>
                        <?php else: ?>
                            <span style="color:gray;">Current Session Profile</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</section>
