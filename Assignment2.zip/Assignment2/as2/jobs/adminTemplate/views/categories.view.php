<section class="left">
    <ul>
        <li><a href="/admin/jobs.php">Manage Jobs</a></li>
        <li><a href="/admin/categories.php">Manage Categories</a></li>
        <li><a href="/admin/enquiries.php">Customer Enquiries Ledger</a></li>
        <li><a href="/admin/users.php">Staff & Client Profiles</a></li>
    </ul>
</section>
<section class="right">
    <h2>Category Classifications</h2>
    <a href="/admin/addcategory.php" style="background:green; color:#fff; padding:5px 10px; text-decoration:none; border-radius:4px;">Add New Category</a><br><br>
    <table border="1" cellpadding="8" style="width:100%; background:#fff; border-collapse:collapse;">
        <thead><tr style="background:#eee;"><th>Category Classification Title</th><th>Actions</th></tr></thead>
        <tbody>
            <?php foreach ($globalCategories as $cat): ?>
                <tr>
                    <td><?= htmlspecialchars((string)$cat['name']) ?></td>
                    <td>
                        <a href="/admin/editcategory.php?id=<?= (int)$cat['id'] ?>">Edit Name</a> | 
                        <form method="POST" action="/admin/deletecategory.php" style="display:inline;" onsubmit="return confirm('Permanently wipe category?');">
                            <input type="hidden" name="id" value="<?= (int)$cat['id'] ?>">
                            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars((string)($csrfToken ?? '')) ?>">
                            <button type="submit" style="background:none; border:none; color:red; padding:0; cursor:pointer;">Wipe Class</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</section>
