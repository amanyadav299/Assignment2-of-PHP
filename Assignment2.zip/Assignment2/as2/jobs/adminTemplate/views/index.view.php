<h2>Administration Access Portal</h2>
<?php if (!empty($error)): ?>
    <div style="color:red; font-weight:bold; margin-bottom:15px;"><?= htmlspecialchars((string)$error) ?></div>
<?php endif; ?>

<form action="/admin/index.php" method="POST" style="background:#fff; padding:20px; border:1px solid #ddd; max-width:400px;">
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars((string)($csrfToken ?? '')) ?>">
    <div style="margin-bottom:10px;">
        <label style="display:block;">Username:</label>
        <input type="text" name="username" required style="width:100%;">
    </div>
    <div style="margin-bottom:10px;">
        <label style="display:block;">Password:</label>
        <input type="password" name="password" required style="width:100%;">
    </div>
    <input type="submit" value="Authenticate Login" style="width:auto; padding:6px 15px;">
</form>

<div style="margin-top:15px;">
    <p>Don't have an account? <a href="/admin/register.php">Register here</a></p>
</div>
