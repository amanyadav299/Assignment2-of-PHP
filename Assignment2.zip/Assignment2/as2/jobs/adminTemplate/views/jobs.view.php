<section class="left">
    <ul>
        <li><a href="/admin/jobs.php">Manage Jobs</a></li>
        <li><a href="/admin/categories.php">Manage Categories</a></li>
        <?php if (\App\Auth::userRole() === 'staff'): ?>
            <li><a href="/admin/enquiries.php">Customer Enquiries Ledger</a></li>
            <li><a href="/admin/users.php">Staff & Client Profiles</a></li>
        <?php endif; ?>
    </ul>
</section>

<section class="right">
    <h2>Job Postings Management Matrix</h2>
    <p>Logged in as: <strong><?= htmlspecialchars(\App\Auth::username()) ?></strong> (<?= htmlspecialchars(\App\Auth::userRole()) ?>)</p>
    <?php if (!empty($statusMessage)): ?>
        <p style="background:#edf7ed; border:1px solid #c6e7c5; color:#2f6b2f; padding:10px; border-radius:4px;"><?= htmlspecialchars((string)$statusMessage) ?></p>
    <?php endif; ?>
    
    <div style="margin-bottom:15px; overflow:auto;">
        <a href="/admin/addjob.php" style="background:green; color:#fff; padding:6px 12px; text-decoration:none; float:left; border-radius:4px;">Post a New Job Opening</a>
        
        <form method="GET" action="/admin/jobs.php" style="float:right; margin:0;">
            <label>Filter List By Category:</label>
            <select name="filter_category" onchange="this.form.submit()">
                <option value="">-- All Categories --</option>
                <?php foreach ($globalCategories as $cat): ?>
                    <option value="<?= (int)$cat['id'] ?>" <?= ((int)$filterCat === (int)$cat['id']) ? 'selected' : '' ?>><?= htmlspecialchars((string)$cat['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </form>
    </div>

    <table border="1" cellpadding="8" style="width:100%; background:#fff; border-collapse:collapse;">
        <thead>
            <tr style="background:#eee;">
                <th>Title</th>
                <th>Category</th>
                <th>Date Received</th>
                <th>Closing Date</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($jobs)): ?>
                <tr><td colspan="6">No postings recorded matching your workspace permissions.</td></tr>
            <?php else: ?>
                <?php foreach ($jobs as $job): ?>
                    <tr>
                        <td><?= htmlspecialchars((string)$job['title']) ?></td>
                        <td><?= htmlspecialchars((string)$job['category_name']) ?></td>
                        <td><?= htmlspecialchars((string)$job['date_received']) ?></td>
                        <td><?= htmlspecialchars((string)$job['closingDate']) ?></td>
                        <td>
                            <?= !empty($job['is_archived']) ? '<span style="color:orange; font-weight:bold;">Archived</span>' : '<span style="color:green; font-weight:bold;">Active</span>' ?>
                        </td>
                        <td>
                            <a href="/admin/editjob.php?id=<?= (int)$job['id'] ?>">Edit</a> | 
                            <a href="/admin/applicants.php?id=<?= (int)$job['id'] ?>">Applicants</a> | 
                            <form method="POST" action="/admin/deletejob.php" style="display:inline;" onsubmit="return confirm('Archive or restore this listing?');">
                                <input type="hidden" name="id" value="<?= (int)$job['id'] ?>">
                                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars((string)($csrfToken ?? '')) ?>">
                                <button type="submit" style="background:none; border:none; color:blue; padding:0; cursor:pointer;"><?= !empty($job['is_archived']) ? 'Restore' : 'Archive' ?></button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</section>
