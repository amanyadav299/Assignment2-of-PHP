<section class="left">
    <ul>
        <li class="<?= $currentCategory === 'it' ? 'current' : '' ?>"><a href="/it.php">IT</a></li>
        <li class="<?= $currentCategory === 'hr' ? 'current' : '' ?>"><a href="/hr.php">Human Resources</a></li>
        <li class="<?= $currentCategory === 'sales' ? 'current' : '' ?>"><a href="/sales.php">Sales</a></li>
    </ul>
</section>

<section class="right">
    <h1><?= htmlspecialchars($heading) ?></h1>
    <ul class="listing">
        <?php if (empty($jobs)): ?>
            <li>No active positions are available at this moment. Please check back later!</li>
        <?php else: ?>
            <?php foreach ($jobs as $job): ?>
                <li>
                    <div class="details">
                        <h2><?= htmlspecialchars($job['title']) ?></h2>
                        <h3><?= htmlspecialchars($job['location']) ?></h3>
                        <h3>Salary: <?= htmlspecialchars($job['salary']) ?></h3>
                        <p><?= nl2br(htmlspecialchars($job['description'])) ?></p>
                        <a class="more" href="/apply.php?id=<?= urlencode($job['id']) ?>">Apply for this job</a>
                    </div>
                </li>
            <?php endforeach; ?>
        <?php endif; ?>
    </ul>
</section>