<p>Welcome to Jo's Jobs, we're a recruitment agency based in Northampton. We offer a range of different office jobs. Get in touch if you'd like to list a job with us.</p>

<h2>Select the type of job you are looking for:</h2>
<div style="display: flex; flex-wrap: wrap; gap: 10px; margin-bottom: 20px;">
    <?php foreach ($globalCategories as $category): ?>
        <a href="/jobs.php?cat=<?= $category['id'] ?>" style="display: inline-block; padding: 10px 15px; background: #007bff; color: white; text-decoration: none; border-radius: 4px; font-weight: bold;">
            <?= htmlspecialchars($category['name']) ?>
        </a>
    <?php endforeach; ?>
</div>