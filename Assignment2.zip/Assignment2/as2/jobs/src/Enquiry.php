<?php
declare(strict_types=1);

namespace App;

use PDO;

class Enquiry
{
    public static function create(PDO $pdo, array $data): int
    {
        $stmt = $pdo->prepare('INSERT INTO enquiry (firstname, surname, email, telephone, enquiry_text, status) VALUES (:firstname, :surname, :email, :telephone, :enquiry_text, :status)');
        $stmt->execute([
            'firstname' => $data['firstname'],
            'surname' => $data['surname'],
            'email' => $data['email'],
            'telephone' => $data['telephone'],
            'enquiry_text' => $data['enquiry_text'],
            'status' => $data['status'],
        ]);
        return (int)$pdo->lastInsertId();
    }

    public static function fetchAll(PDO $pdo): array
    {
        $stmt = $pdo->query('SELECT e.*, u.username AS staff_username FROM enquiry e LEFT JOIN user u ON e.staff_id = u.id ORDER BY e.created_at DESC');
        return $stmt->fetchAll();
    }

    public static function markComplete(PDO $pdo, int $id, int $staffId): void
    {
        $stmt = $pdo->prepare('UPDATE enquiry SET status = "Complete", staff_id = :staffId WHERE id = :id');
        $stmt->execute(['staffId' => $staffId, 'id' => $id]);
    }
}
