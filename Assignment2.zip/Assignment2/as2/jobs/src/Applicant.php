<?php
declare(strict_types=1);

namespace App;

use PDO;

class Applicant
{
    public static function create(PDO $pdo, array $data): int
    {
        $stmt = $pdo->prepare('INSERT INTO applicants (name, email, details, jobId, cv) VALUES (:name, :email, :details, :jobId, :cv)');
        $stmt->execute([
            'name' => $data['name'],
            'email' => $data['email'],
            'details' => $data['details'],
            'jobId' => $data['jobId'],
            'cv' => $data['cv'],
        ]);
        return (int)$pdo->lastInsertId();
    }

    public static function fetchByJobId(PDO $pdo, int $jobId): array
    {
        $stmt = $pdo->prepare('SELECT * FROM applicants WHERE jobId = :jobId');
        $stmt->execute(['jobId' => $jobId]);
        return $stmt->fetchAll();
    }
}
