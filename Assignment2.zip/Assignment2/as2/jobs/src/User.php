<?php
declare(strict_types=1);

namespace App;

use PDO;

class User
{
    public static function fetchByUsername(PDO $pdo, string $username): ?array
    {
        $stmt = $pdo->prepare('SELECT * FROM user WHERE username = :username');
        $stmt->execute(['username' => $username]);
        $row = $stmt->fetch();
        return $row === false ? null : $row;
    }

    public static function create(PDO $pdo, string $username, string $passwordHash, string $role): bool
    {
        $stmt = $pdo->prepare('INSERT INTO user (username, password, role) VALUES (:username, :password, :role)');
        return $stmt->execute([
            'username' => $username,
            'password' => $passwordHash,
            'role' => $role,
        ]);
    }

    public static function delete(PDO $pdo, int $id): void
    {
        $stmt = $pdo->prepare('DELETE FROM user WHERE id = :id');
        $stmt->execute(['id' => $id]);
    }

    public static function fetchAll(PDO $pdo): array
    {
        $stmt = $pdo->query('SELECT id, username, role FROM user ORDER BY username ASC');
        return $stmt->fetchAll();
    }
}
