<?php
declare(strict_types=1);

namespace App;

use PDO;

class Category
{
    public static function create(PDO $pdo, string $name): int
    {
        $stmt = $pdo->prepare('INSERT INTO category (name) VALUES (:name)');
        $stmt->execute(['name' => $name]);

        return (int)$pdo->lastInsertId();
    }

    public static function update(PDO $pdo, int $id, string $name): void
    {
        $stmt = $pdo->prepare('UPDATE category SET name = :name WHERE id = :id');
        $stmt->execute(['name' => $name, 'id' => $id]);
    }

    public static function delete(PDO $pdo, int $id): void
    {
        $stmt = $pdo->prepare('DELETE FROM category WHERE id = :id');
        $stmt->execute(['id' => $id]);
    }

    public static function fetchAll(PDO $pdo): array
    {
        $stmt = $pdo->query('SELECT * FROM category ORDER BY name ASC');
        return $stmt->fetchAll();
    }

    public static function findById(PDO $pdo, int $id): ?array
    {
        $stmt = $pdo->prepare('SELECT * FROM category WHERE id = :id');
        $stmt->execute(['id' => $id]);
        $row = $stmt->fetch();
        return $row === false ? null : $row;
    }
}
