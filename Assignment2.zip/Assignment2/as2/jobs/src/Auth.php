<?php

declare(strict_types=1);

namespace App;

class Auth
{
    public static function isLoggedIn(): bool
    {
        return !empty($_SESSION['loggedin']);
    }

    public static function requireLogin(): void
    {
        if (!self::isLoggedIn()) {
            redirect('/admin/index.php');
        }
    }

    public static function requireStaff(): void
    {
        if (!self::isLoggedIn() || (string)($_SESSION['user_role'] ?? '') !== 'staff') {
            redirect('/admin/jobs.php');
        }
    }

    public static function requireRole(string $role): void
    {
        if (!self::isLoggedIn() || (string)($_SESSION['user_role'] ?? '') !== $role) {
            redirect('/admin/jobs.php');
        }
    }

    public static function userId(): int
    {
        return (int)($_SESSION['user_id'] ?? 0);
    }

    public static function userRole(): string
    {
        return (string)($_SESSION['user_role'] ?? '');
    }

    public static function username(): string
    {
        return (string)($_SESSION['username'] ?? '');
    }

    public static function canManageJob(array $job): bool
    {
        return self::userRole() === 'staff' || self::userId() === (int)($job['userId'] ?? 0);
    }

    public static function logout(): void
    {
        $_SESSION = [];

        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
        }

        session_destroy();
        redirect('/admin/index.php');
    }
}
