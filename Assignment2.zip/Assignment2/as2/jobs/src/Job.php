<?php
declare(strict_types=1);

namespace App;

use PDO;

class Job
{
    public static function validateInput(array $data): array
    {
        $errors = [];

        $title = trim((string)($data['title'] ?? ''));
        $description = trim((string)($data['description'] ?? ''));
        $salary = trim((string)($data['salary'] ?? ''));
        $location = trim((string)($data['location'] ?? ''));
        $closingDate = trim((string)($data['closingDate'] ?? ''));
        $categoryId = (int)($data['categoryId'] ?? 0);

        if ($title === '') {
            $errors[] = 'Job title is required.';
        }

        if ($description === '') {
            $errors[] = 'A job description is required.';
        }

        if ($location === '') {
            $errors[] = 'Location is required.';
        }

        if ($salary === '' || !is_numeric($salary) || (float)$salary < 0) {
            $errors[] = 'Salary must be a valid number.';
        }

        if ($closingDate === '' || strtotime($closingDate) === false) {
            $errors[] = 'A valid closing date is required.';
        }

        if ($categoryId <= 0) {
            $errors[] = 'Please choose a category.';
        }

        return [
            'valid' => $errors === [],
            'errors' => $errors,
            'data' => [
                'title' => $title,
                'description' => $description,
                'salary' => $salary,
                'location' => $location,
                'closingDate' => $closingDate,
                'categoryId' => $categoryId,
            ],
        ];
    }

    public static function search(PDO $pdo, ?int $categoryId, string $title, string $location): array
    {
        $sql = 'SELECT * FROM job WHERE is_archived = 0 AND closingDate >= :today';
        $params = [ 'today' => date('Y-m-d') ];

        if ($categoryId !== null) {
            $sql .= ' AND categoryId = :catId';
            $params['catId'] = $categoryId;
        }

        if ($title !== '') {
            $sql .= ' AND title LIKE :title';
            $params['title'] = '%' . $title . '%';
        }

        if ($location !== '') {
            $sql .= ' AND location LIKE :location';
            $params['location'] = '%' . $location . '%';
        }

        $sql .= ' ORDER BY date_received DESC';
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);

        return $stmt->fetchAll();
    }

    public static function fetchById(PDO $pdo, int $id): ?array
    {
        $stmt = $pdo->prepare('SELECT * FROM job WHERE id = :id');
        $stmt->execute(['id' => $id]);
        $row = $stmt->fetch();
        return $row === false ? null : $row;
    }

    public static function fetchClosingSoon(PDO $pdo, int $limit = 5): array
    {
        $stmt = $pdo->prepare('SELECT * FROM job WHERE is_archived = 0 AND closingDate >= :today ORDER BY closingDate ASC LIMIT :limit');
        $stmt->bindValue('today', date('Y-m-d'));
        $stmt->bindValue('limit', $limit, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll();
    }

    public static function fetchForAdmin(PDO $pdo, string $role, ?int $userId, ?int $categoryId): array
    {
        $sql = 'SELECT j.*, c.name AS category_name FROM job j JOIN category c ON j.categoryId = c.id';
        $params = [];

        if ($role === 'client') {
            $sql .= ' WHERE j.userId = :userId';
            $params['userId'] = $userId;
        }

        if ($categoryId !== null) {
            $sql .= $role === 'client' ? ' AND ' : ' WHERE ';
            $sql .= 'j.categoryId = :catId';
            $params['catId'] = $categoryId;
        }

        $sql .= ' ORDER BY j.date_received DESC';
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);

        return $stmt->fetchAll();
    }

    public static function create(PDO $pdo, array $data): int
    {
        $stmt = $pdo->prepare('INSERT INTO job (title, description, salary, location, closingDate, categoryId, userId, is_archived) VALUES (:title, :description, :salary, :location, :closingDate, :categoryId, :userId, 0)');
        $stmt->execute([
            'title' => $data['title'],
            'description' => $data['description'],
            'salary' => $data['salary'],
            'location' => $data['location'],
            'closingDate' => $data['closingDate'],
            'categoryId' => $data['categoryId'],
            'userId' => $data['userId'],
        ]);

        return (int)$pdo->lastInsertId();
    }

    public static function update(PDO $pdo, int $id, array $data): void
    {
        $stmt = $pdo->prepare('UPDATE job SET title = :title, description = :description, salary = :salary, location = :location, closingDate = :closingDate, categoryId = :categoryId WHERE id = :id');
        $stmt->execute([
            'title' => $data['title'],
            'description' => $data['description'],
            'salary' => $data['salary'],
            'location' => $data['location'],
            'closingDate' => $data['closingDate'],
            'categoryId' => $data['categoryId'],
            'id' => $id,
        ]);
    }

    public static function toggleArchive(PDO $pdo, int $id, bool $archive): void
    {
        $stmt = $pdo->prepare('UPDATE job SET is_archived = :archive WHERE id = :id');
        $stmt->execute(['archive' => $archive ? 1 : 0, 'id' => $id]);
    }
}
