<?php
declare(strict_types=1);

namespace App;

use PDO;
use PDOException;

class Database
{
    public static function getConnection(): PDO
    {
        static $pdo = null;
        if ($pdo instanceof PDO) {
            return $pdo;
        }

        $dsn = sprintf('mysql:host=%s;dbname=%s;charset=utf8mb4', getenv('DB_HOST') ?: 'mysql', getenv('DB_NAME') ?: 'job');
        $user = getenv('DB_USER') ?: 'student';
        $password = getenv('DB_PASSWORD') ?: 'student';

        try {
            $pdo = new PDO($dsn, $user, $password, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]);
        } catch (PDOException $e) {
            die('Database connection failed: ' . $e->getMessage());
        }

        return $pdo;
    }
}
