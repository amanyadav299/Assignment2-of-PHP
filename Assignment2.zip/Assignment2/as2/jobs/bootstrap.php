<?php
declare(strict_types=1);

require_once __DIR__ . '/vendor/autoload.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

use App\Database;
use App\Category;

$pdo = Database::getConnection();
$globalCategories = Category::fetchAll($pdo);

function renderPage(string $title, string $content): void
{
    global $globalCategories;
    require __DIR__ . '/adminTemplate/layout.html.php';
}

function redirect(string $location): void
{
    header('Location: ' . $location);
    exit();
}

function escape(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

function renderView(string $viewName, array $data = []): void
{
    extract($data, EXTR_SKIP);

    $viewPaths = [
        __DIR__ . '/adminTemplate/views/' . $viewName . '.view.php',
        __DIR__ . '/public/views/' . $viewName . '.view.php',
    ];

    foreach ($viewPaths as $viewPath) {
        if (is_file($viewPath)) {
            require $viewPath;
            return;
        }
    }

    throw new RuntimeException('View not found: ' . $viewName);
}

function getRequestValue(string $key, string $default = ''): string
{
    return trim((string)($_REQUEST[$key] ?? $default));
}

function getPostValue(string $key, string $default = ''): string
{
    return trim((string)($_POST[$key] ?? $default));
}

function getQueryValue(string $key, string $default = ''): string
{
    return trim((string)($_GET[$key] ?? $default));
}

function generateCsrfToken(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }

    return $_SESSION['csrf_token'];
}

function validateCsrfToken(string $token): bool
{
    return hash_equals($_SESSION['csrf_token'] ?? '', $token);
}

function isLoggedIn(): bool
{
    return !empty($_SESSION['loggedin']);
}

function requireRole(string $role): void
{
    if (!isLoggedIn() || ($_SESSION['user_role'] ?? '') !== $role) {
        redirect('/admin/jobs.php');
    }
}
