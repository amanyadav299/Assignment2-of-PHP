<?php

declare(strict_types=1);

namespace App;

use PDO;

class ApplicantController
{
    public function create(PDO $pdo, array $data): int
    {
        return Applicant::create($pdo, $data);
    }

    public function index(PDO $pdo, int $jobId): array
    {
        return Applicant::fetchByJobId($pdo, $jobId);
    }
}
