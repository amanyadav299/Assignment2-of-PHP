<?php

declare(strict_types=1);

namespace App;

use App\Category;
use PDO;

class CategoryController
{
    public function index(PDO $pdo): array
    {
        return Category::fetchAll($pdo);
    }

    public function show(PDO $pdo, int $id): ?array
    {
        return Category::findById($pdo, $id);
    }

    public function store(PDO $pdo, string $name): bool
    {
        $name = trim($name);
        if ($name === '') {
            return false;
        }

        Category::create($pdo, $name);
        return true;
    }

    public function update(PDO $pdo, int $id, string $name): bool
    {
        $name = trim($name);
        if ($id <= 0 || $name === '') {
            return false;
        }

        Category::update($pdo, $id, $name);
        return true;
    }

    public function destroy(PDO $pdo, int $id): bool
    {
        if ($id <= 0) {
            return false;
        }

        Category::delete($pdo, $id);
        return true;
    }
}