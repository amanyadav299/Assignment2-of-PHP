<?php

declare(strict_types=1);

namespace App;

use PDO;

class EnquiryController
{
    public function index(PDO $pdo): array
    {
        return Enquiry::fetchAll($pdo);
    }

    public function resolve(PDO $pdo, int $id, int $staffId): void
    {
        Enquiry::markComplete($pdo, $id, $staffId);
    }
}
