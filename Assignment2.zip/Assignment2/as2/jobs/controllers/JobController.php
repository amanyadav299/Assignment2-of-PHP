<?php

declare(strict_types=1);

namespace App;

use PDO;

class JobController
{
    public function index(PDO $pdo, string $role, int $userId, ?int $categoryId): array
    {
        return Job::fetchForAdmin($pdo, $role, $userId, $categoryId);
    }

    public function show(PDO $pdo, int $id): ?array
    {
        return Job::fetchById($pdo, $id);
    }

    public function create(PDO $pdo, array $data): int
    {
        return Job::create($pdo, $data);
    }

    public function update(PDO $pdo, int $id, array $data): void
    {
        Job::update($pdo, $id, $data);
    }

    public function toggleArchive(PDO $pdo, int $id, bool $archive): void
    {
        Job::toggleArchive($pdo, $id, $archive);
    }

    public function applicants(PDO $pdo, int $jobId): array
    {
        $stmt = $pdo->prepare('SELECT * FROM applicants WHERE jobId = :jobId');
        $stmt->execute(['jobId' => $jobId]);

        return $stmt->fetchAll();
    }
}
