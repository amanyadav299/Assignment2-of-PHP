CREATE DATABASE IF NOT EXISTS `job` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `job`;

-- Categories Table
CREATE TABLE IF NOT EXISTS `category` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Users Table (Covers Staff & Client Workspace Access Isolation)
CREATE TABLE IF NOT EXISTS `user` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(100) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `role` ENUM('staff', 'client') NOT NULL DEFAULT 'staff',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Job Table (With Date Received, Archived Flag, and User Reference)
CREATE TABLE IF NOT EXISTS `job` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `title` VARCHAR(255) NOT NULL,
  `description` TEXT NOT NULL,
  `salary` VARCHAR(100) DEFAULT NULL,
  `location` VARCHAR(255) DEFAULT NULL,
  `closingDate` DATE NOT NULL,
  `date_received` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `categoryId` INT(11) NOT NULL,
  `userId` INT(11) NOT NULL,
  `is_archived` TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`categoryId`) REFERENCES `category`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`userId`) REFERENCES `user`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Applicants Table
CREATE TABLE IF NOT EXISTS `applicants` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(255) NOT NULL,
  `email` VARCHAR(255) NOT NULL,
  `details` TEXT NOT NULL,
  `jobId` INT(11) NOT NULL,
  `cv` VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`jobId`) REFERENCES `job`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Enquiries Table
CREATE TABLE IF NOT EXISTS `enquiry` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `firstname` VARCHAR(100) NOT NULL,
  `surname` VARCHAR(100) NOT NULL,
  `email` VARCHAR(255) NOT NULL,
  `telephone` VARCHAR(50) NOT NULL,
  `enquiry_text` TEXT NOT NULL,
  `status` ENUM('Pending', 'Complete') NOT NULL DEFAULT 'Pending',
  `staff_id` INT(11) DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`staff_id`) REFERENCES `user`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Seed categories used by the site
INSERT INTO `category` (`id`, `name`) VALUES
(1, 'IT'), (2, 'Human Resources'), (4, 'Sales')
ON DUPLICATE KEY UPDATE `name` = VALUES(`name`);

-- Seed admin user: username Admin, password letmein
INSERT INTO `user` (`username`, `password`, `role`)
VALUES ('Admin', '$2y$10$q/teq0OdnD9nzUGdNKsole3cySG0tu54aynuoyZsUxEfAlvvDEgsm', 'staff')
ON DUPLICATE KEY UPDATE `username` = VALUES(`username`);
