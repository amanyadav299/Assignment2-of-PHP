<?php

use App\Enquiry;
use PHPUnit\Framework\TestCase;

class EnquiryTest extends TestCase
{
    private function createPdo(): \PDO
    {
        $pdo = new \PDO('sqlite::memory:');
        $pdo->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
        $pdo->exec('CREATE TABLE enquiry (id INTEGER PRIMARY KEY AUTOINCREMENT, firstname TEXT, surname TEXT, email TEXT, telephone TEXT, enquiry_text TEXT, status TEXT, staff_id INTEGER, created_at TEXT DEFAULT CURRENT_TIMESTAMP)');
        $pdo->exec('CREATE TABLE user (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT)');

        return $pdo;
    }

    public function testCreateStoresEnquiry(): void
    {
        $pdo = $this->createPdo();

        $id = Enquiry::create($pdo, [
            'firstname' => 'Jane',
            'surname' => 'Doe',
            'email' => 'jane@example.com',
            'telephone' => '1234',
            'enquiry_text' => 'Need help',
            'status' => 'Open',
        ]);

        $this->assertSame(1, $id);
        $this->assertSame('Jane', $pdo->query('SELECT firstname FROM enquiry')->fetchColumn());
    }

    public function testFetchAllReturnsStaffUsername(): void
    {
        $pdo = $this->createPdo();
        $pdo->exec("INSERT INTO user (id, username) VALUES (1, 'staffone')");
        $pdo->exec("INSERT INTO enquiry (id, firstname, surname, email, telephone, enquiry_text, status, staff_id) VALUES (1, 'Jane', 'Doe', 'jane@example.com', '1234', 'Hello', 'Open', 1)");

        $rows = Enquiry::fetchAll($pdo);

        $this->assertCount(1, $rows);
        $this->assertSame('staffone', $rows[0]['staff_username']);
    }

    public function testMarkCompleteUpdatesStatusAndStaffId(): void
    {
        $pdo = $this->createPdo();
        $pdo->exec("INSERT INTO enquiry (id, firstname, surname, email, telephone, enquiry_text, status) VALUES (1, 'Jane', 'Doe', 'jane@example.com', '1234', 'Hello', 'Open')");

        Enquiry::markComplete($pdo, 1, 4);

        $row = $pdo->query('SELECT status, staff_id FROM enquiry WHERE id = 1')->fetch();
        $this->assertSame('Complete', $row['status']);
        $this->assertSame(4, (int) $row['staff_id']);
    }
}
