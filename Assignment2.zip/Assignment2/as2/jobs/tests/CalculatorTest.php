<?php

require_once __DIR__ . '/../classes/Adder.php';

use PHPUnit\Framework\TestCase;

class CalculatorTest extends TestCase
{
    private function makeCalculator(): Adder
    {
        return new Adder();
    }

    public function testAddReturnsSumOfPositiveNumbers(): void
    {
        $this->assertSame(5, $this->makeCalculator()->add(2, 3));
    }

    public function testAddHandlesZeroValues(): void
    {
        $this->assertSame(7, $this->makeCalculator()->add(7, 0));
    }

    public function testAddHandlesNegativeNumbers(): void
    {
        $this->assertSame(-1, $this->makeCalculator()->add(-4, 3));
    }

    public function testAddIsCommutative(): void
    {
        $calc = $this->makeCalculator();

        $this->assertSame($calc->add(4, 6), $calc->add(6, 4));
    }

    public function testAddSupportsLargeIntegers(): void
    {
        $this->assertSame(100000, $this->makeCalculator()->add(50000, 50000));
    }

    public function testAddReturnsIntegerValue(): void
    {
        $result = $this->makeCalculator()->add(10, 20);

        $this->assertIsInt($result);
    }

    public function testAddWithDecimalNumbers(): void
    {
        $this->assertEquals(3.5, $this->makeCalculator()->add(1.2, 2.3));
    }

    public function testAddWithMixedSigns(): void
    {
        $this->assertSame(2, $this->makeCalculator()->add(-1, 3));
    }

    public function testAddWithRepeatedValues(): void
    {
        $this->assertSame(8, $this->makeCalculator()->add(4, 4));
    }

    public function testAddMaintainsSameResultAcrossCalls(): void
    {
        $calc = $this->makeCalculator();

        $first = $calc->add(8, 2);
        $second = $calc->add(8, 2);

        $this->assertSame($first, $second);
    }
}