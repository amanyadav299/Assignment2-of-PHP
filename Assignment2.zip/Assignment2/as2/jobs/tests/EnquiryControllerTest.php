<?php

use App\EnquiryController;
use PHPUnit\Framework\TestCase;

class EnquiryControllerTest extends TestCase
{
    private function createPdo(): PDO
    {
        $pdo = new PDO('sqlite::memory:');
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->exec('CREATE TABLE enquiry (id INTEGER PRIMARY KEY AUTOINCREMENT, firstname TEXT, surname TEXT, email TEXT, telephone TEXT, enquiry_text TEXT, status TEXT, staff_id INTEGER, created_at TEXT DEFAULT CURRENT_TIMESTAMP)');
        $pdo->exec('CREATE TABLE user (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT)');
        return $pdo;
    }

    public function testResolveMarksEnquiryComplete(): void
    {
        $pdo = $this->createPdo();
        $pdo->exec("INSERT INTO enquiry (id, firstname, surname, email, telephone, enquiry_text, status) VALUES (1, 'Jane', 'Doe', 'jane@example.com', '1234', 'Need help', 'Open')");
        $controller = new EnquiryController();

        $controller->resolve($pdo, 1, 4);

        $row = $pdo->query('SELECT status, staff_id FROM enquiry WHERE id = 1')->fetch();
        $this->assertSame('Complete', $row['status']);
        $this->assertSame(4, (int) $row['staff_id']);
    }
}
