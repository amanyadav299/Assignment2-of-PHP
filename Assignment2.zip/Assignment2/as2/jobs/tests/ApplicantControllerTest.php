<?php

use App\ApplicantController;
use PHPUnit\Framework\TestCase;

class ApplicantControllerTest extends TestCase
{
    private function createPdo(): PDO
    {
        $pdo = new PDO('sqlite::memory:');
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->exec('CREATE TABLE applicants (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, email TEXT, details TEXT, jobId INTEGER, cv TEXT)');
        return $pdo;
    }

    public function testCreateStoresApplicantThroughController(): void
    {
        $pdo = $this->createPdo();
        $controller = new ApplicantController();

        $id = $controller->create($pdo, [
            'name' => 'Ava',
            'email' => 'ava@example.com',
            'details' => 'Interested',
            'jobId' => 5,
            'cv' => 'cv.pdf',
        ]);

        $this->assertSame(1, $id);
        $this->assertSame('Ava', $pdo->query('SELECT name FROM applicants')->fetchColumn());
    }
}
