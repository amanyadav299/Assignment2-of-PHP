<?php

use App\Category;
use PHPUnit\Framework\TestCase;

class CategoryTest extends TestCase
{
    private function createPdo(): \PDO
    {
        $pdo = new \PDO('sqlite::memory:');
        $pdo->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
        $pdo->exec('CREATE TABLE category (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL)');

        return $pdo;
    }

    public function testCreateReturnsInsertedId(): void
    {
        $pdo = $this->createPdo();

        $id = Category::create($pdo, 'Finance');

        $this->assertSame(1, $id);
    }

    public function testUpdateChangesTheStoredName(): void
    {
        $pdo = $this->createPdo();
        Category::create($pdo, 'Old');

        Category::update($pdo, 1, 'New');

        $this->assertSame('New', Category::findById($pdo, 1)['name']);
    }

    public function testDeleteRemovesTheCategory(): void
    {
        $pdo = $this->createPdo();
        Category::create($pdo, 'Delete');

        Category::delete($pdo, 1);

        $this->assertNull(Category::findById($pdo, 1));
    }

    public function testFetchAllReturnsSortedRows(): void
    {
        $pdo = $this->createPdo();
        Category::create($pdo, 'Zulu');
        Category::create($pdo, 'Alpha');

        $rows = Category::fetchAll($pdo);

        $this->assertCount(2, $rows);
        $this->assertSame('Alpha', $rows[0]['name']);
    }
}
