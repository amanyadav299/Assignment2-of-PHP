<?php

use App\Job;
use PHPUnit\Framework\TestCase;

class JobValidationTest extends TestCase
{
    public function testValidateInputRejectsBlankFieldsAndInvalidSalary(): void
    {
        $result = Job::validateInput([
            'title' => '   ',
            'description' => '',
            'salary' => 'not-a-number',
            'location' => '',
            'closingDate' => '2020-01-01',
            'categoryId' => 0,
        ]);

        $this->assertFalse($result['valid']);
        $this->assertNotEmpty($result['errors']);
        $this->assertStringContainsString('Job title', $result['errors'][0]);
    }

    public function testValidateInputAcceptsWellFormedData(): void
    {
        $result = Job::validateInput([
            'title' => 'Developer',
            'description' => 'Build features',
            'salary' => '45000',
            'location' => 'Bristol',
            'closingDate' => date('Y-m-d', strtotime('+30 days')),
            'categoryId' => 1,
        ]);

        $this->assertTrue($result['valid']);
        $this->assertSame([], $result['errors']);
    }
}
