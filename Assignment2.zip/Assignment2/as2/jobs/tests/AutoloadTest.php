<?php

use App\CategoryController;
use PHPUnit\Framework\TestCase;

class AutoloadTest extends TestCase
{
    public function testCategoryControllerIsAvailableViaComposerAutoload(): void
    {
        $controller = new CategoryController();

        $this->assertInstanceOf(CategoryController::class, $controller);
    }
}
