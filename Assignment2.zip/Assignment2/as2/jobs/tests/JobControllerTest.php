<?php

use App\JobController;
use PHPUnit\Framework\TestCase;

class JobControllerTest extends TestCase
{
    private function createPdo(): PDO
    {
        $pdo = new PDO('sqlite::memory:');
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->exec('CREATE TABLE job (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, description TEXT, salary TEXT, location TEXT, closingDate TEXT, categoryId INTEGER, userId INTEGER, is_archived INTEGER DEFAULT 0, date_received TEXT DEFAULT CURRENT_TIMESTAMP)');
        $pdo->exec('CREATE TABLE category (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL)');
        return $pdo;
    }

    public function testIndexReturnsJobsForClientScope(): void
    {
        $pdo = $this->createPdo();
        $pdo->exec("INSERT INTO category (id, name) VALUES (1, 'IT')");
        $pdo->exec("INSERT INTO job (id, title, description, salary, location, closingDate, categoryId, userId, is_archived) VALUES (1, 'Developer', 'Build', '50000', 'London', '2030-01-01', 1, 7, 0)");

        $controller = new JobController();

        $jobs = $controller->index($pdo, 'client', 7, null);

        $this->assertCount(1, $jobs);
        $this->assertSame('Developer', $jobs[0]['title']);
    }
}
