<?php

use App\Category;
use App\CategoryController;
use PHPUnit\Framework\TestCase;

class CategoryControllerTest extends TestCase
{
    private function createPdo(): \PDO
    {
        $pdo = new \PDO('sqlite::memory:');
        $pdo->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
        $pdo->exec('CREATE TABLE category (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL)');

        return $pdo;
    }

    public function testIndexReturnsEmptyArrayWhenNoCategories(): void
    {
        $controller = new CategoryController();

        $this->assertSame([], $controller->index($this->createPdo()));
    }

    public function testStoreCreatesCategoryAndReturnsTrue(): void
    {
        $pdo = $this->createPdo();
        $controller = new CategoryController();

        $this->assertTrue($controller->store($pdo, 'IT'));
        $this->assertSame('IT', $controller->show($pdo, 1)['name']);
    }

    public function testStoreRejectsBlankName(): void
    {
        $controller = new CategoryController();

        $this->assertFalse($controller->store($this->createPdo(), '   '));
    }

    public function testStoreTrimsWhitespaceBeforeSaving(): void
    {
        $pdo = $this->createPdo();
        $controller = new CategoryController();

        $this->assertTrue($controller->store($pdo, '  HR  '));
        $this->assertSame('HR', $controller->show($pdo, 1)['name']);
    }

    public function testShowReturnsNullForUnknownId(): void
    {
        $controller = new CategoryController();

        $this->assertNull($controller->show($this->createPdo(), 999));
    }

    public function testShowReturnsStoredCategory(): void
    {
        $pdo = $this->createPdo();
        Category::create($pdo, 'Sales');
        $controller = new CategoryController();

        $result = $controller->show($pdo, 1);

        $this->assertIsArray($result);
        $this->assertSame('Sales', $result['name']);
    }

    public function testUpdateRejectsNonPositiveId(): void
    {
        $controller = new CategoryController();

        $this->assertFalse($controller->update($this->createPdo(), 0, 'Admin'));
    }

    public function testUpdateRejectsBlankName(): void
    {
        $controller = new CategoryController();

        $this->assertFalse($controller->update($this->createPdo(), 1, '   '));
    }

    public function testUpdateUpdatesExistingCategory(): void
    {
        $pdo = $this->createPdo();
        Category::create($pdo, 'Old');
        $controller = new CategoryController();

        $this->assertTrue($controller->update($pdo, 1, 'New'));
        $this->assertSame('New', $controller->show($pdo, 1)['name']);
    }

    public function testDestroyRejectsNonPositiveId(): void
    {
        $controller = new CategoryController();

        $this->assertFalse($controller->destroy($this->createPdo(), 0));
    }

    public function testDestroyDeletesExistingCategory(): void
    {
        $pdo = $this->createPdo();
        Category::create($pdo, 'Deleted');
        $controller = new CategoryController();

        $this->assertTrue($controller->destroy($pdo, 1));
        $this->assertNull($controller->show($pdo, 1));
    }
}