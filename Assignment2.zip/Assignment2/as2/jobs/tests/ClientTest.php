
<?php

require_once __DIR__ . '/../classes/Client.php';

use PHPUnit\Framework\TestCase;

class ClientTest extends TestCase
{
    private function captureViewOutput(): string
    {
        ob_start();
        (new Client())->view();

        return (string) ob_get_clean();
    }

    public function testViewDisplayText(): void
    {
        $this->expectOutputString('Client View');

        (new Client())->view();
    }

    public function testViewOutputMatchesExpectedText(): void
    {
        $this->assertSame('Client View', $this->captureViewOutput());
    }

    public function testViewOutputIsNotEmpty(): void
    {
        $this->assertNotEmpty($this->captureViewOutput());
    }

    public function testViewOutputIsString(): void
    {
        $this->assertIsString($this->captureViewOutput());
    }

    public function testViewOutputContainsClientWord(): void
    {
        $this->assertStringContainsString('Client', $this->captureViewOutput());
    }

    public function testViewOutputContainsViewWord(): void
    {
        $this->assertStringContainsString('View', $this->captureViewOutput());
    }

    public function testViewOutputHasExpectedLength(): void
    {
        $this->assertSame(11, strlen($this->captureViewOutput()));
    }

    public function testViewOutputStartsWithClient(): void
    {
        $this->assertStringStartsWith('Client', $this->captureViewOutput());
    }

    public function testViewOutputEndsWithView(): void
    {
        $this->assertStringEndsWith('View', $this->captureViewOutput());
    }

    public function testViewCanBeCalledRepeatedly(): void
    {
        $first = $this->captureViewOutput();
        $second = $this->captureViewOutput();

        $this->assertSame($first, $second);
    }
}