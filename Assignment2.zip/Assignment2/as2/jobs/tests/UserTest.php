<?php

use App\User;
use PHPUnit\Framework\TestCase;

class UserTest extends TestCase
{
    private function createPdo(): \PDO
    {
        $pdo = new \PDO('sqlite::memory:');
        $pdo->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
        $pdo->exec('CREATE TABLE user (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT, password TEXT, role TEXT)');

        return $pdo;
    }

    public function testFetchByUsernameReturnsNullWhenMissing(): void
    {
        $this->assertNull(User::fetchByUsername($this->createPdo(), 'missing'));
    }

    public function testCreateReturnsTrueAndFetchByUsernameFindsUser(): void
    {
        $pdo = $this->createPdo();

        $created = User::create($pdo, 'alice', 'hash', 'staff');
        $row = User::fetchByUsername($pdo, 'alice');

        $this->assertTrue($created);
        $this->assertSame('alice', $row['username']);
        $this->assertSame('staff', $row['role']);
    }

    public function testDeleteRemovesTheUser(): void
    {
        $pdo = $this->createPdo();
        User::create($pdo, 'bob', 'hash', 'client');

        User::delete($pdo, 1);

        $this->assertNull(User::fetchByUsername($pdo, 'bob'));
    }

    public function testFetchAllReturnsOrderedUsers(): void
    {
        $pdo = $this->createPdo();
        User::create($pdo, 'zeta', 'h', 'client');
        User::create($pdo, 'alpha', 'h', 'staff');

        $rows = User::fetchAll($pdo);

        $this->assertCount(2, $rows);
        $this->assertSame('alpha', $rows[0]['username']);
    }
}
