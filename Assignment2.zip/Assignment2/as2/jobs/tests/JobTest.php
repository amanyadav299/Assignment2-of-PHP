<?php

use App\Job;
use PHPUnit\Framework\TestCase;

class JobTest extends TestCase
{
    private function createPdo(): \PDO
    {
        $pdo = new \PDO('sqlite::memory:');
        $pdo->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
        $pdo->exec('CREATE TABLE category (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT)');
        $pdo->exec('CREATE TABLE job (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, description TEXT, salary TEXT, location TEXT, closingDate TEXT, categoryId INTEGER, userId INTEGER, is_archived INTEGER, date_received TEXT DEFAULT CURRENT_TIMESTAMP)');

        return $pdo;
    }

    public function testSearchReturnsOnlyMatchingOpenJobs(): void
    {
        $pdo = $this->createPdo();
        $pdo->exec("INSERT INTO category (id, name) VALUES (1, 'IT')");
        $pdo->exec("INSERT INTO job (id, title, description, salary, location, closingDate, categoryId, userId, is_archived) VALUES (1, 'Developer', 'Build apps', '5000', 'Perth', '2099-12-31', 1, 2, 0)");
        $pdo->exec("INSERT INTO job (id, title, description, salary, location, closingDate, categoryId, userId, is_archived) VALUES (2, 'Designer', 'Make UI', '4500', 'Sydney', '2099-12-31', 1, 2, 1)");

        $rows = Job::search($pdo, 1, 'Developer', '');

        $this->assertCount(1, $rows);
        $this->assertSame('Developer', $rows[0]['title']);
    }

    public function testFetchByIdAndFetchClosingSoon(): void
    {
        $pdo = $this->createPdo();
        $pdo->exec("INSERT INTO job (id, title, description, salary, location, closingDate, categoryId, userId, is_archived) VALUES (1, 'Analyst', 'Data', '6000', 'Brisbane', '2099-01-01', 1, 2, 0)");

        $this->assertSame('Analyst', Job::fetchById($pdo, 1)['title']);
        $this->assertCount(1, Job::fetchClosingSoon($pdo, 5));
    }

    public function testCreateUpdateAndToggleArchive(): void
    {
        $pdo = $this->createPdo();
        $id = Job::create($pdo, [
            'title' => 'Manager',
            'description' => 'Lead team',
            'salary' => '7000',
            'location' => 'Melbourne',
            'closingDate' => '2099-11-11',
            'categoryId' => 1,
            'userId' => 2,
        ]);

        Job::update($pdo, $id, [
            'title' => 'Senior Manager',
            'description' => 'Lead team',
            'salary' => '8000',
            'location' => 'Melbourne',
            'closingDate' => '2099-11-11',
            'categoryId' => 1,
        ]);
        Job::toggleArchive($pdo, $id, true);

        $row = Job::fetchById($pdo, $id);
        $this->assertSame('Senior Manager', $row['title']);
        $this->assertSame(1, (int) $row['is_archived']);
    }

    public function testFetchForAdminFiltersByRoleAndCategory(): void
    {
        $pdo = $this->createPdo();
        $pdo->exec("INSERT INTO category (id, name) VALUES (1, 'IT')");
        $pdo->exec("INSERT INTO job (id, title, description, salary, location, closingDate, categoryId, userId, is_archived) VALUES (1, 'Dev', 'desc', '5000', 'Perth', '2099-12-31', 1, 2, 0)");

        $rows = Job::fetchForAdmin($pdo, 'client', 2, 1);

        $this->assertCount(1, $rows);
        $this->assertSame('Dev', $rows[0]['title']);
    }
}
