<?php

use App\Database;
use PHPUnit\Framework\TestCase;

class DatabaseTest extends TestCase
{
    public function testGetConnectionReturnsPdoInstance(): void
    {
        $pdo = Database::getConnection();

        $this->assertInstanceOf(\PDO::class, $pdo);
    }

    public function testGetConnectionReturnsSameInstanceOnRepeatedCalls(): void
    {
        $first = Database::getConnection();
        $second = Database::getConnection();

        $this->assertSame($first, $second);
    }
}
