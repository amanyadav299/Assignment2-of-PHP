<?php

use App\Applicant;
use PHPUnit\Framework\TestCase;

class ApplicantTest extends TestCase
{
    private function createPdo(): \PDO
    {
        $pdo = new \PDO('sqlite::memory:');
        $pdo->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
        $pdo->exec('CREATE TABLE applicants (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, email TEXT, details TEXT, jobId INTEGER, cv TEXT)');

        return $pdo;
    }

    public function testCreateStoresApplicantData(): void
    {
        $pdo = $this->createPdo();

        $id = Applicant::create($pdo, [
            'name' => 'Ava',
            'email' => 'ava@example.com',
            'details' => 'Experienced',
            'jobId' => 7,
            'cv' => 'cv.pdf',
        ]);

        $this->assertSame(1, $id);
        $this->assertSame('Ava', $pdo->query('SELECT name FROM applicants')->fetchColumn());
    }

    public function testFetchByJobIdReturnsMatchingApplicants(): void
    {
        $pdo = $this->createPdo();
        Applicant::create($pdo, ['name' => 'A', 'email' => 'a@test', 'details' => 'd', 'jobId' => 2, 'cv' => 'a.pdf']);
        Applicant::create($pdo, ['name' => 'B', 'email' => 'b@test', 'details' => 'd', 'jobId' => 2, 'cv' => 'b.pdf']);
        Applicant::create($pdo, ['name' => 'C', 'email' => 'c@test', 'details' => 'd', 'jobId' => 9, 'cv' => 'c.pdf']);

        $rows = Applicant::fetchByJobId($pdo, 2);

        $this->assertCount(2, $rows);
        $this->assertSame('A', $rows[0]['name']);
    }
}
