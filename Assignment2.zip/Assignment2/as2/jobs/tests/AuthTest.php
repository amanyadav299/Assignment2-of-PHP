<?php

use App\Auth;
use PHPUnit\Framework\TestCase;

class AuthTest extends TestCase
{
    protected function setUp(): void
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        $_SESSION = [];
    }

    public function testIsLoggedInReturnsFalseWhenSessionEmpty(): void
    {
        $this->assertFalse(Auth::isLoggedIn());
    }

    public function testUserHelpersReturnSessionValues(): void
    {
        $_SESSION['loggedin'] = true;
        $_SESSION['user_id'] = 42;
        $_SESSION['user_role'] = 'staff';
        $_SESSION['username'] = 'admin';

        $this->assertTrue(Auth::isLoggedIn());
        $this->assertSame(42, Auth::userId());
        $this->assertSame('staff', Auth::userRole());
        $this->assertSame('admin', Auth::username());
    }

    public function testCanManageJobAllowsOwnerOrStaff(): void
    {
        $_SESSION['user_role'] = 'staff';
        $_SESSION['user_id'] = 10;

        $this->assertTrue(Auth::canManageJob(['userId' => 10]));
        $this->assertTrue(Auth::canManageJob(['userId' => 99]));

        $_SESSION['user_role'] = 'client';
        $this->assertFalse(Auth::canManageJob(['userId' => 99]));
    }
}
