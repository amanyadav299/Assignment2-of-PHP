<?php

class Client
{
    public function view()
    {
        echo 'Client View';
    }
}
