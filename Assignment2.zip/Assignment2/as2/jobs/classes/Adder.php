<?php

declare(strict_types=1);

final class Adder
{
    public function add(int|float $a, int|float $b): int|float
    {
        return $a + $b;
    }
}


