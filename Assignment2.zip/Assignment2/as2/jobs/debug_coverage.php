<?php
require 'vendor/autoload.php';

use SebastianBergmann\CodeCoverage\Report\Xml\Project;
use SebastianBergmann\CodeCoverage\Report\Xml\Report;

try {
    $project = new Project('/var/www/html/src');
    echo "project-ok\n";
    $report = new Report('/var/www/html/src/Job.php');
    echo "report-ok\n";
} catch (Throwable $e) {
    echo get_class($e) . ': ' . $e->getMessage() . "\n";
    echo $e->getTraceAsString() . "\n";
}
