<h1>Contact Our Support Team</h1>
<p>Telephone: 01604 123456<br>Email: contact@josjobs.com</p>

<?php if (!empty($successMessage)): ?>
    <div style="background:#d4edda; color:#155724; padding:10px; margin-bottom:20px; border-radius:4px;">
        <?= htmlspecialchars((string)$successMessage) ?>
    </div>
<?php endif; ?>

<form action="/contact.php" method="POST" style="background:#fff; padding:20px; border:1px solid #ddd;">
    <div style="margin-bottom:10px;">
        <label style="display:block;">First Name:</label>
        <input type="text" name="firstname" required style="width:100%; max-width:400px;">
    </div>
    <div style="margin-bottom:10px;">
        <label style="display:block;">Surname:</label>
        <input type="text" name="surname" required style="width:100%; max-width:400px;">
    </div>
    <div style="margin-bottom:10px;">
        <label style="display:block;">Email Address:</label>
        <input type="email" name="email" required style="width:100%; max-width:400px;">
    </div>
    <div style="margin-bottom:10px;">
        <label style="display:block;">Telephone Number:</label>
        <input type="text" name="telephone" required style="width:100%; max-width:400px;">
    </div>
    <div style="margin-bottom:10px;">
        <label style="display:block;">Your Enquiry:</label>
        <textarea name="enquiry_text" required style="width:100%; max-width:400px; height:120px;"></textarea>
    </div>
    <input type="submit" value="Submit Enquiry" style="width:auto; padding:7px 20px;">
</form>
