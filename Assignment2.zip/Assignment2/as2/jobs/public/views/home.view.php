<h2>Welcome to Jo's Jobs</h2>
<p>We are a premier recruitment agency based in Northampton. We match outstanding talent with leading companies.</p>

<div style="background: #f9f9f9; padding: 15px; border: 1px solid #ddd; margin-top: 20px; margin-bottom: 20px;">
    <h3 style="margin-top: 0;">Browse Jobs by Category</h3>
    <div style="display: flex; flex-wrap: wrap; gap: 10px;">
        <?php foreach ($globalCategories as $category): ?>
            <a href="/jobs.php?cat=<?= (int)$category['id'] ?>" style="display: inline-block; padding: 10px 15px; background: #007bff; color: white; text-decoration: none; border-radius: 4px; font-weight: bold;">
                <?= htmlspecialchars((string)$category['name']) ?>
            </a>
        <?php endforeach; ?>
    </div>
</div>

<div class="closing-soonest-section" style="background: #fff; padding: 15px; border: 1px solid #ddd; margin-top: 20px;">
    <h3 style="color: #d9534f; margin-top: 0;">⚠️ Urgent Openings - Closing Soon!</h3>
    <?php if (empty($upcomingJobs)): ?>
        <p>No jobs closing soon.</p>
    <?php else: ?>
        <ul class="listing">
            <?php foreach ($upcomingJobs as $job): ?>
                <li>
                    <div class="details">
                        <h2><?= htmlspecialchars((string)$job['title']) ?></h2>
                        <h3>Location: <?= htmlspecialchars((string)$job['location']) ?></h3>
                        <p style="color: red; font-weight: bold;">Closing Date: <?= htmlspecialchars((string)$job['closingDate']) ?></p>
                        <a class="more" href="/apply.php?id=<?= (int)$job['id'] ?>">Apply Now</a>
                    </div>
                </li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>
</div>
