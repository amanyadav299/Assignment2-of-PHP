<section class="left">
    <ul>
        <li><a href="/jobs.php">All Jobs</a></li>
        <li><a href="/admin/jobs.php">Admin Dashboard</a></li>
    </ul>
</section>

<section class="right">
    <?php if (!empty($successMessage)): ?>
        <div style="background:#e0ffd8; padding:15px; margin-bottom:15px; border:1px solid #b7e89d;">
            <?= htmlspecialchars((string)$successMessage) ?>
        </div>
    <?php elseif (!empty($errorMessage)): ?>
        <div style="background:#ffe8e8; padding:15px; margin-bottom:15px; border:1px solid #e8b7b7;">
            <?= htmlspecialchars((string)$errorMessage) ?>
        </div>
    <?php endif; ?>

    <?php if (empty($successMessage)): ?>
        <form action="/apply.php" method="POST" enctype="multipart/form-data" style="background:#fff; padding:20px; border:1px solid #ddd;">
            <div style="margin-bottom:10px;">
                <label>Name:</label>
                <input type="text" name="name" required style="width:100%;" />
            </div>
            <div style="margin-bottom:10px;">
                <label>Email:</label>
                <input type="email" name="email" required style="width:100%;" />
            </div>
            <div style="margin-bottom:10px;">
                <label>Cover Letter:</label>
                <textarea name="details" required style="width:100%; height:150px;"></textarea>
            </div>
            <div style="margin-bottom:10px;">
                <label>Upload CV:</label>
                <input type="file" name="cv" required />
            </div>
            <input type="hidden" name="jobId" value="<?= (int)$job['id'] ?>" />
            <input type="submit" name="submit" value="Submit Application" style="width:auto; padding:8px 20px;" />
        </form>
    <?php endif; ?>
</section>
