<section class="left">
    <ul>
        <?php foreach ($globalCategories as $cat): ?>
            <li class="<?= ((string)$selectedCatId === (string)$cat['id']) ? 'current' : '' ?>">
                <a href="/jobs.php?cat=<?= (int)$cat['id'] ?>"><?= htmlspecialchars((string)$cat['name']) ?></a>
            </li>
        <?php endforeach; ?>
    </ul>
</section>

<section class="right">
    <h1><?= htmlspecialchars((string)$categoryName) ?></h1>

    <form method="GET" action="/jobs.php" style="background:#f9f9f9; padding:15px; margin-bottom:20px; border:1px solid #eee;">
        <?php if ($selectedCatId !== ''): ?>
            <input type="hidden" name="cat" value="<?= htmlspecialchars((string)$selectedCatId) ?>">
        <?php endif; ?>
        <div style="margin-bottom: 10px;">
            <label style="display:inline-block; width:100px;">Job Title:</label>
            <input type="text" name="search_title" value="<?= htmlspecialchars((string)$searchTitle) ?>" placeholder="e.g. Developer">
        </div>
        <div style="margin-bottom: 10px;">
            <label style="display:inline-block; width:100px;">Location:</label>
            <input type="text" name="search_location" value="<?= htmlspecialchars((string)$searchLocation) ?>" placeholder="e.g. Northampton">
        </div>
        <input type="submit" value="Search Listings" style="width:auto; padding:5px 15px; margin-left:100px;">
    </form>

    <ul class="listing">
        <?php if (empty($jobs)): ?>
            <li>No active job openings found matching your filter selections.</li>
        <?php else: ?>
            <?php foreach ($jobs as $job): ?>
                <li>
                    <div class="details">
                        <h2><?= htmlspecialchars((string)$job['title']) ?></h2>
                        <h3>Location: <?= htmlspecialchars((string)$job['location']) ?> | Salary: <?= htmlspecialchars((string)$job['salary']) ?></h3>
                        <p><?= nl2br(htmlspecialchars((string)$job['description'])) ?></p>
                        <p><strong>Closing Date:</strong> <?= htmlspecialchars((string)$job['closingDate']) ?></p>
                        <a class="more" href="/apply.php?id=<?= (int)$job['id'] ?>">Apply for this job</a>
                    </div>
                </li>
            <?php endforeach; ?>
        <?php endif; ?>
    </ul>
</section>
