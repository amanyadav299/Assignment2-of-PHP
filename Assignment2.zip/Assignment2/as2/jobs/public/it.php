<?php
// public/it.php
header('Location: /jobs.php?cat=1');
exit();