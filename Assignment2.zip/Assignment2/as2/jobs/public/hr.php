<?php
// public/hr.php
header('Location: /jobs.php?cat=2');
exit();