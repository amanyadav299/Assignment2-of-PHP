<?php
// public/sales.php
header('Location: /jobs.php?cat=4');
exit();