<?php
require __DIR__ . '/../bootstrap.php';

$selectedCatId = getQueryValue('cat');
$searchTitle = getQueryValue('search_title');
$searchLocation = getQueryValue('search_location');

// Fetch currently selected category details for headers
$categoryName = "All Job Listings";
if ($selectedCatId !== '') {
    $catRow = \App\Category::findById($pdo, (int)$selectedCatId);
    if ($catRow) {
        $categoryName = $catRow['name'] . ' Jobs';
    }
}

$title = $categoryName;
$jobs = \App\Job::search(
    $pdo,
    $selectedCatId !== '' ? (int)$selectedCatId : null,
    $searchTitle,
    $searchLocation
);

ob_start();
renderView('jobs-listings', [
    'jobs' => $jobs,
    'globalCategories' => $globalCategories,
    'selectedCatId' => $selectedCatId,
    'searchTitle' => $searchTitle,
    'searchLocation' => $searchLocation,
    'categoryName' => $categoryName,
]);
$content = ob_get_clean();
renderPage($title, $content);