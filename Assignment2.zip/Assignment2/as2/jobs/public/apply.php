<?php
require __DIR__ . '/../bootstrap.php';

$title = 'Apply for a Job';
$successMessage = '';
$errorMessage = '';
$applicantController = new \App\ApplicantController();
$job = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $job = \App\Job::fetchById($pdo, (int)getPostValue('jobId'));

    if ($job === null) {
        $errorMessage = 'The selected job posting could not be found.';
    } elseif (!isset($_FILES['cv']) || $_FILES['cv']['error'] !== UPLOAD_ERR_OK) {
        $errorMessage = 'Please upload a CV before submitting your application.';
    } else {
        $allowedExtensions = ['pdf', 'doc', 'docx'];
        $fileInfo = pathinfo($_FILES['cv']['name']);
        $extension = strtolower($fileInfo['extension'] ?? '');

        if (!in_array($extension, $allowedExtensions, true)) {
            $errorMessage = 'CV uploads must be a PDF, DOC or DOCX file.';
        } else {
            $cvDirectory = __DIR__ . '/cvs';
            if (!is_dir($cvDirectory)) {
                mkdir($cvDirectory, 0755, true);
            }

            $fileName = uniqid('cv_', true) . '.' . $extension;
            move_uploaded_file($_FILES['cv']['tmp_name'], $cvDirectory . '/' . $fileName);

            $applicantController->create($pdo, [
                'name' => getPostValue('name'),
                'email' => getPostValue('email'),
                'details' => getPostValue('details'),
                'jobId' => (int)getPostValue('jobId'),
                'cv' => $fileName,
            ]);

            $successMessage = 'Your application is complete. We will contact you after the closing date.';
        }
    }
} else {
    $job = \App\Job::fetchById($pdo, (int)getQueryValue('id'));
}

if ($job === null) {
    die('Application failed: Job listing not found.');
}

ob_start();
renderView('apply', ['job' => $job, 'successMessage' => $successMessage, 'errorMessage' => $errorMessage]);
$content = ob_get_clean();
renderPage($title, $content);


