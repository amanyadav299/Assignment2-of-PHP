<?php
require __DIR__ . '/../bootstrap.php';

$title = 'Contact Us';
$successMessage = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    \App\Enquiry::create($pdo, [
        'firstname'   => getPostValue('firstname'),
        'surname'     => getPostValue('surname'),
        'email'       => getPostValue('email'),
        'telephone'   => getPostValue('telephone'),
        'enquiry_text'=> getPostValue('enquiry_text'),
        'status'      => 'Pending',
    ]);
    $successMessage = 'Thank you! Your enquiry has been received and securely cataloged for processing.';
}

ob_start();
renderView('contact', ['successMessage' => $successMessage]);
$content = ob_get_clean();
renderPage($title, $content);