<?php
require __DIR__ . '/../bootstrap.php';

$title = 'Careers Advice';

ob_start();
renderView('careers');
$content = ob_get_clean();
renderPage($title, $content);