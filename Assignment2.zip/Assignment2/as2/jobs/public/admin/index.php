<?php
require __DIR__ . '/../../bootstrap.php';

$title = 'Admin Authentication';
$error = '';
$csrfToken = generateCsrfToken();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCsrfToken(getPostValue('csrf_token'))) {
        $error = 'Invalid security token. Please try again.';
    } else {
        $username = getPostValue('username');
        $password = getPostValue('password');

        $stmt = $pdo->prepare('SELECT * FROM user WHERE username = :username');
        $stmt->execute(['username' => $username]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['loggedin'] = true;
            $_SESSION['user_id'] = (int)$user['id'];
            $_SESSION['user_role'] = (string)$user['role'];
            $_SESSION['username'] = (string)$user['username'];
            header('Location: /admin/jobs.php');
            exit();
        } else {
            $error = 'Authentication Failed: Invalid username or password entry.';
        }
    }
}

ob_start();
renderView('index', ['error' => $error, 'csrfToken' => $csrfToken]);
$content = ob_get_clean();
renderPage($title, $content);