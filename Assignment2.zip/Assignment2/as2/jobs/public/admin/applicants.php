<?php
require __DIR__ . '/../../bootstrap.php';

\App\Auth::requireLogin();

$jobController = new \App\JobController();
$applicantController = new \App\ApplicantController();
$id = (int)($_GET['id'] ?? 0);
$job = $jobController->show($pdo, $id);

if (!$job) {
    redirect('/admin/jobs.php');
}

// Enforce client scope protection rules
if (\App\Auth::userRole() === 'client' && $job['userId'] != \App\Auth::userId()) {
    header('Location: /admin/jobs.php');
    exit();
}

$applicants = $applicantController->index($pdo, $id);

$title = 'Job Applicants';
ob_start();
?>
<h2>Applications Received for: <?= htmlspecialchars($job['title']) ?></h2>
<table border="1" cellpadding="8" style="width:100%; background:#fff; border-collapse:collapse;">
    <thead>
        <tr style="background:#eee;">
            <th>Applicant Name</th>
            <th>Email</th>
            <th>Details / Supporting Statement</th>
            <th>CV Document</th>
        </tr>
    </thead>
    <tbody>
        <?php if (empty($applicants)): ?>
            <tr><td colspan="4">No candidates have applied for this vacancy yet.</td></tr>
        <?php else: ?>
            <?php foreach ($applicants as $app): ?>
                <tr>
                    <td><?= htmlspecialchars($app['name']) ?></td>
                    <td><?= htmlspecialchars($app['email']) ?></td>
                    <td><?= nl2br(htmlspecialchars($app['details'])) ?></td>
                    <td>
                        <?php if (!empty($app['cv'])): ?>
                            <a href="/cvs/<?= htmlspecialchars($app['cv']) ?>" target="_blank">Download File</a>
                        <?php else: ?>
                            None Uploaded
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
    </tbody>
</table>
<p><a href="/admin/jobs.php">« Return to Dashboard</a></p>
<?php
$content = ob_get_clean();
renderPage($title, $content);