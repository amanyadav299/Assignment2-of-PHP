<?php
require __DIR__ . '/../../bootstrap.php';

\App\Auth::requireLogin();

$jobController = new \App\JobController();
$id = (int)getPostValue('id');

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !validateCsrfToken(getPostValue('csrf_token'))) {
    redirect('/admin/jobs.php');
}

$job = $jobController->show($pdo, $id);

if ($job) {
    // Multi-tenant permission guard verification check
    if (\App\Auth::userRole() === 'client' && $job['userId'] != \App\Auth::userId()) {
        header('Location: /admin/jobs.php');
        exit();
    }
    
    // Toggle active state flag via the shared model class
    $newArchiveState = $job['is_archived'] ? false : true;
    $jobController->toggleArchive($pdo, $id, $newArchiveState);
}

header('Location: /admin/jobs.php');
exit();