<?php
require __DIR__ . '/../../bootstrap.php';

\App\Auth::requireLogin();

$id = getQueryValue('id');
$stmt = $pdo->prepare('SELECT * FROM job WHERE id = :id');
$stmt->execute(['id' => $id]);
$job = $stmt->fetch();

if (!$job) {
    redirect('/admin/jobs.php');
}

// Security Boundary Guard: Clients cannot update jobs belonging to other accounts via URL manipulation
if (\App\Auth::userRole() === 'client' && $job['userId'] != \App\Auth::userId()) {
    header('Location: /admin/jobs.php');
    exit();
}

$jobController = new \App\JobController();
$csrfToken = generateCsrfToken();
$error = '';
$formData = [
    'title' => getPostValue('title'),
    'description' => getPostValue('description'),
    'salary' => getPostValue('salary'),
    'location' => getPostValue('location'),
    'closingDate' => getPostValue('closingDate'),
    'categoryId' => (int)getPostValue('categoryId'),
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCsrfToken(getPostValue('csrf_token'))) {
        $error = 'Invalid security token. Please try again.';
    } else {
        $validation = \App\Job::validateInput($formData);

        if (!$validation['valid']) {
            $error = implode(' ', $validation['errors']);
        } else {
            $jobController->update($pdo, (int)$id, [
                'title' => $validation['data']['title'],
                'description' => $validation['data']['description'],
                'salary' => $validation['data']['salary'],
                'location' => $validation['data']['location'],
                'closingDate' => $validation['data']['closingDate'],
                'categoryId' => $validation['data']['categoryId'],
            ]);
            redirect('/admin/jobs.php?status=updated');
        }
    }
}

$title = 'Edit Job Posting';
ob_start();
renderView('editjob', [
    'csrfToken' => $csrfToken,
    'job' => $job,
    'globalCategories' => $globalCategories,
    'error' => $error,
    'formData' => $formData,
]);
$content = ob_get_clean();
renderPage($title, $content);