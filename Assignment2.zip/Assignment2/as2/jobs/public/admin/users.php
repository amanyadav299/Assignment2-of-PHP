<?php
require __DIR__ . '/../../bootstrap.php';

\App\Auth::requireStaff();

$message = '';
$csrfToken = generateCsrfToken();
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_user'])) {
    if (!validateCsrfToken(getPostValue('csrf_token'))) {
        $message = 'Invalid security token. Please try again.';
    } else {
        $username = getPostValue('username');
        $password = getPostValue('password');
        $role = getPostValue('role');

        if ($username === '' || $password === '' || $role === '') {
            $message = 'All profile fields are required.';
        } else {
            $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
            try {
                \App\User::create($pdo, $username, $hashedPassword, $role);
                $message = 'User profile created successfully!';
            } catch (PDOException $e) {
                $message = 'Error: That username is already taken.';
            }
        }
    }
}

// Process Account Deletion Request
$deleteId = (int)getQueryValue('delete_id');
if ($deleteId > 0) {
    if ($deleteId === \App\Auth::userId()) {
        $message = 'Error: You cannot delete your own logged-in session profile.';
    } else {
        \App\User::delete($pdo, $deleteId);
        redirect('/admin/users.php');
    }
}

$allUsers = \App\User::fetchAll($pdo);

$title = 'Account Profiles Management';
ob_start();
renderView('users', ['message' => $message, 'csrfToken' => $csrfToken, 'allUsers' => $allUsers]);
$content = ob_get_clean();
renderPage($title, $content);