<?php
require __DIR__ . '/../../bootstrap.php';
\App\Auth::requireStaff();

$controller = new \App\CategoryController();
$id = (int)getQueryValue('id');
$csrfToken = generateCsrfToken();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCsrfToken(getPostValue('csrf_token'))) {
        redirect('/admin/categories.php');
    }

    if (!$controller->update($pdo, $id, getPostValue('name'))) {
        redirect('/admin/categories.php');
    }

    redirect('/admin/categories.php');
}

$cat = $controller->show($pdo, $id);

$title = 'Edit Category';
ob_start();
renderView('editcategory', ['csrfToken' => $csrfToken, 'cat' => $cat]);
$content = ob_get_clean();
renderPage($title, $content);