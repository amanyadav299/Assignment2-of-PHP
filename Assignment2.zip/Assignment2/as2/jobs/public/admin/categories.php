<?php
require __DIR__ . '/../../bootstrap.php';
\App\Auth::requireStaff();

$controller = new \App\CategoryController();
$csrfToken = generateCsrfToken();
$globalCategories = $controller->index($pdo);

$title = 'Manage Categories';
ob_start();
renderView('categories', ['globalCategories' => $globalCategories, 'csrfToken' => $csrfToken]);
$content = ob_get_clean();
renderPage($title, $content);