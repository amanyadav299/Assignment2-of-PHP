<?php
require __DIR__ . '/../../bootstrap.php';
\App\Auth::requireStaff();

$controller = new \App\CategoryController();
$csrfToken = generateCsrfToken();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCsrfToken(getPostValue('csrf_token'))) {
        redirect('/admin/categories.php');
    }

    if (!$controller->store($pdo, getPostValue('name'))) {
        redirect('/admin/addcategory.php');
    }

    redirect('/admin/categories.php');
}

$title = 'Add Category';
ob_start();
renderView('addcategory', ['csrfToken' => $csrfToken]);
$content = ob_get_clean();
renderPage($title, $content);