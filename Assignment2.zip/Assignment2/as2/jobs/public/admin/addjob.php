<?php
require __DIR__ . '/../../bootstrap.php';

\App\Auth::requireLogin();

$jobController = new \App\JobController();
$csrfToken = generateCsrfToken();
$error = '';
$formData = [
    'title' => getPostValue('title'),
    'description' => getPostValue('description'),
    'salary' => getPostValue('salary'),
    'location' => getPostValue('location'),
    'closingDate' => getPostValue('closingDate'),
    'categoryId' => (int)getPostValue('categoryId'),
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCsrfToken(getPostValue('csrf_token'))) {
        $error = 'Invalid security token. Please try again.';
    } else {
        $validation = \App\Job::validateInput($formData);

        if (!$validation['valid']) {
            $error = implode(' ', $validation['errors']);
        } else {
            $jobController->create($pdo, [
                'title' => $validation['data']['title'],
                'description' => $validation['data']['description'],
                'salary' => $validation['data']['salary'],
                'location' => $validation['data']['location'],
                'closingDate' => $validation['data']['closingDate'],
                'categoryId' => $validation['data']['categoryId'],
                'userId' => \App\Auth::userId(),
            ]);
            redirect('/admin/jobs.php?status=created');
        }
    }
}

$title = 'Post New Job';
ob_start();
renderView('addjob', [
    'csrfToken' => $csrfToken,
    'globalCategories' => $globalCategories,
    'error' => $error,
    'formData' => $formData,
]);
$content = ob_get_clean();
renderPage($title, $content);