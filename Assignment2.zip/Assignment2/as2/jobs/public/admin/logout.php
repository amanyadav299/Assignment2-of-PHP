<?php
require __DIR__ . '/../../bootstrap.php';

\App\Auth::logout();