<?php
require __DIR__ . '/../../bootstrap.php';

\App\Auth::requireLogin();

$title = 'Manage Jobs Panel';
$filterCat = (int)(getQueryValue('filter_category') !== '' ? getQueryValue('filter_category') : 0);
$jobController = new \App\JobController();
$csrfToken = generateCsrfToken();
$statusMessage = '';

if (getQueryValue('status') === 'created') {
    $statusMessage = 'Job listing published successfully.';
}

if (getQueryValue('status') === 'updated') {
    $statusMessage = 'Job listing updated successfully.';
}

// Role Isolation: Clients only see jobs matching their own userId. Staff members can see all entries.
$jobs = $jobController->index(
    $pdo,
    (string)$_SESSION['user_role'],
    (int)$_SESSION['user_id'],
    $filterCat > 0 ? $filterCat : null
);

ob_start();
renderView('jobs', ['jobs' => $jobs, 'filterCat' => $filterCat, 'globalCategories' => $globalCategories, 'statusMessage' => $statusMessage, 'csrfToken' => $csrfToken]);
$content = ob_get_clean();
renderPage($title, $content);