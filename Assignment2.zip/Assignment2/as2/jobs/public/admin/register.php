<?php
require __DIR__ . '/../../bootstrap.php';

$title = 'Admin Registration';
$error = '';
$success = '';
$csrfToken = generateCsrfToken();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCsrfToken(getPostValue('csrf_token'))) {
        $error = 'Invalid security token. Please try again.';
    } else {
        $username = getPostValue('username');
        $password = getPostValue('password');
        $confirmPassword = getPostValue('confirm_password');

        // Validation
        if (empty($username) || empty($password) || empty($confirmPassword)) {
            $error = 'All fields are required.';
        } elseif (strlen($username) < 3) {
            $error = 'Username must be at least 3 characters long.';
        } elseif (strlen($password) < 6) {
            $error = 'Password must be at least 6 characters long.';
        } elseif ($password !== $confirmPassword) {
            $error = 'Passwords do not match.';
        } else {
            // Check if username already exists
            $stmt = $pdo->prepare('SELECT id FROM user WHERE username = :username');
            $stmt->execute(['username' => $username]);
            if ($stmt->fetch()) {
                $error = 'Username already exists. Please choose a different username.';
            } else {
                // Create the account
                $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
                try {
                    \App\User::create($pdo, $username, $hashedPassword, 'staff');
                    $success = 'Registration successful! Redirecting to login...';
                    header('refresh:2; url=/admin/index.php');
                } catch (PDOException $e) {
                    $error = 'An error occurred during registration. Please try again.';
                }
            }
        }
    }
}

ob_start();
renderView('register', ['error' => $error, 'success' => $success, 'csrfToken' => $csrfToken]);
$content = ob_get_clean();
renderPage($title, $content);
