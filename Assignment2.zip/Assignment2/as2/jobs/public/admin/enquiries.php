<?php
require __DIR__ . '/../../bootstrap.php';

// Strict Staff-only page visibility guard
\App\Auth::requireStaff();

$enquiryController = new \App\EnquiryController();
$csrfToken = generateCsrfToken();

// Mark Enquiry as Complete action processing mapping block
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['resolve_id'])) {
    if (!validateCsrfToken(getPostValue('csrf_token'))) {
        redirect('/admin/enquiries.php');
    }

    $resolveId = (int)getPostValue('resolve_id');
    if ($resolveId > 0) {
        $enquiryController->resolve($pdo, $resolveId, \App\Auth::userId());
    }
    redirect('/admin/enquiries.php');
}

// Fetch all entries, joined with the user table to display the staff member's username
$enquiries = $enquiryController->index($pdo);

$title = 'Enquiries Ledger';
ob_start();
renderView('enquiries', ['enquiries' => $enquiries, 'csrfToken' => $csrfToken]);
$content = ob_get_clean();
renderPage($title, $content);