<?php
require __DIR__ . '/../../bootstrap.php';
\App\Auth::requireStaff();

$controller = new \App\CategoryController();
$id = (int)getPostValue('id');

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !validateCsrfToken(getPostValue('csrf_token'))) {
    redirect('/admin/categories.php');
}

if ($id > 0) {
    $controller->destroy($pdo, $id);
}

redirect('/admin/categories.php');
