<?php
require __DIR__ . '/../bootstrap.php';

$title = 'Home';

// Fetch the 5 jobs closing soonest
$upcomingJobs = \App\Job::fetchClosingSoon($pdo);

ob_start();
renderView('home', ['upcomingJobs' => $upcomingJobs, 'globalCategories' => $globalCategories]);
$content = ob_get_clean();
renderPage($title, $content);