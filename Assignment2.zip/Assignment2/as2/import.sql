-- Adminer 5.4.2 MariaDB 12.2.2-MariaDB-ubu2404 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `applicants`;
CREATE TABLE `applicants` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `details` text NOT NULL,
  `jobId` int(11) NOT NULL,
  `cv` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `jobId` (`jobId`),
  CONSTRAINT `1` FOREIGN KEY (`jobId`) REFERENCES `job` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;


DROP TABLE IF EXISTS `category`;
CREATE TABLE `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

INSERT INTO `category` (`id`, `name`) VALUES
(1,	'IT'),
(2,	'Human Resources'),
(4,	'Sales');

DROP TABLE IF EXISTS `enquiry`;
CREATE TABLE `enquiry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `surname` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `telephone` varchar(50) NOT NULL,
  `enquiry_text` text NOT NULL,
  `status` enum('Pending','Complete') NOT NULL DEFAULT 'Pending',
  `staff_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `staff_id` (`staff_id`),
  CONSTRAINT `1` FOREIGN KEY (`staff_id`) REFERENCES `user` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

INSERT INTO `enquiry` (`id`, `firstname`, `surname`, `email`, `telephone`, `enquiry_text`, `status`, `staff_id`, `created_at`) VALUES
(1,	'Aman kumar',	'Yadav',	'as123@gmail.com',	'1234567890',	'enquiry',	'Complete',	2,	'2026-06-03 03:13:24');

DROP TABLE IF EXISTS `job`;
CREATE TABLE `job` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `salary` varchar(100) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `closingDate` date NOT NULL,
  `date_received` timestamp NULL DEFAULT current_timestamp(),
  `categoryId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `is_archived` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `categoryId` (`categoryId`),
  KEY `userId` (`userId`),
  CONSTRAINT `1` FOREIGN KEY (`categoryId`) REFERENCES `category` (`id`) ON DELETE CASCADE,
  CONSTRAINT `2` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

INSERT INTO `job` (`id`, `title`, `description`, `salary`, `location`, `closingDate`, `date_received`, `categoryId`, `userId`, `is_archived`) VALUES
(1,	'Manager',	'Manger post',	'50000',	'nepal',	'2026-07-31',	'2026-06-03 03:09:37',	2,	2,	1);

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('staff','client') NOT NULL DEFAULT 'staff',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

INSERT INTO `user` (`id`, `username`, `password`, `role`) VALUES
(1,	'Admin',	'$2y$10$q/teq0OdnD9nzUGdNKsole3cySG0tu54aynuoyZsUxEfAlvvDEgsm',	'staff'),
(2,	'Aman',	'$2y$10$NtShluPlWyUVED9qhSgHzOV0zjvNHpxyUmkqoVHV.8ISFddmS3UWa',	'staff'),
(3,	'user',	'$2y$10$4OJ.AQ9NeiYa2XBjsL7UyupzMz4KHt7ZksEVrfVMNkE3Au5jW.Ppe',	'client');

-- 2026-07-03 15:49:59 UTC
